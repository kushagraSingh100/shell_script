#!/bin/bash

# Check if exactly two arguments are provided
if [ "$#" -ne 2 ]; then
    echo "2 filenames arguments not provided"
    echo "Usage: $0 <input_filename> <output_filename>"
    exit 1
fi

# Store filenames in variables
input_file="$1"
output_file="$2"

# Check if the input file exists
if [ ! -f "$input_file" ]; then
    echo "Error: '$input_file' not found!"
    exit 1
fi

if [ ! -f "$output_file" ]; then
	echo "Error: '$output_file' not found!"
	read -p "Do you want to create a new output file? (y/n): " choice
	case "$choice" in
	     [Yy]* )
		 echo "File '$output_file' created."
		 ;;
	     * )
		 echo "Exiting without creating a new file. "
		 exit 1
		;;
	esac
fi


#Find the overall average
overall_average=$(awk -F ',' 'NR>1 {sum+=$4; count++} END {print sum/count}' "$input_file")

#Unique cities in the given data file:
echo "------------------" >> "$output_file"
echo "Unique cities in the given data file:" >> "$output_file"
awk -F ',' 'NR>1 {sub(/^ */, "", $3); print $3}' "$input_file" | sort -u >> "$output_file"

# Find the top 3 individuals with the highest salary and save their details to the output file
echo "------------------" >> "$output_file"
echo "Details of top 3 individuals with the highest salary:" >> "$output_file"
awk -F ',' 'NR>1 {print $4 "," $0}' "$input_file" | sort -t ',' -k1nr | head -n 3 | cut -d ',' -f 2- >> "$output_file"

# The average salary for each city in the dataset and save it to the output file
echo "-------------------" >> "$output_file"
echo "Details of average salary of each City:" >> "$output_file"
awk -F ',' 'NR>1 {sum[$3]+=$4; count[$3]++} END {for (city in sum) print "City: " city ", Salary: " sum[city]/count[city]}' "$input_file" >> "$output_file"

# Identifying individuals with a salary above the overall average salary and save their details to the output file

echo "-------------------" >> "$output_file"
echo "Details of individuals with a salary above the overall average salary:" >> "$output_file"
awk -F ',' -v avg="$overall_average" '{if ($4 > avg) print $0}' "$input_file" >> "$output_file"

echo "task completed"
